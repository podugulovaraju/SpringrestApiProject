package com.axyya.application.Entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "server")
public class Server {
    @Id
    Long id;
    String name;
    String language;
    String framework;
    
    public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getLanguage() {
		return language;
	}



	public void setLanguage(String language) {
		this.language = language;
	}



	public String getFramework() {
		return framework;
	}



	public void setFramework(String framework) {
		this.framework = framework;
	}

@Override
public String toString() {
    return "Server{" +"sId=" + id +", sName='" + name + '\'' +", sLanguage='" + language + '\'' +", sFramework='" + framework + '\'' + '}';
    }

}

