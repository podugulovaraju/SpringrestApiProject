package com.axyya.application.ExceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "page not found")
 public class ServerException extends RuntimeException{
    String message;
    public ServerException(String message) {
        super(message);
    }
}
