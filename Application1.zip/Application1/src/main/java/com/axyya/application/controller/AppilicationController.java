package com.axyya.application.controller;

import com.axyya.application.Entity.Server;
import com.axyya.application.service.ApplicationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class AppilicationController {

	@Autowired
    ApplicationService Service;

	    @GetMapping("/server")
	    List<Server> getServer()
	    {
	        return Service.getService();
	    }
	    @GetMapping("/server/{id}")
	    public Server getServer(@PathVariable Long id)
	    {
	        return Service.getByID(id);
	    }
	    @GetMapping("/byName/{name}")
	    public List<Server> getByName(@PathVariable String name)
	    {
	        return Service.getByName(name);
	    }
	    @PostMapping("/server")
	    Server saveData(@RequestBody Server server) {
	        return Service.saveServerData(server);
	    }

	    @PutMapping("/server/{id}")
	    public Server updateServer(@RequestBody Server server, @PathVariable Long id) {
	        this.Service.updateServer(server,id);
	        return Service.saveServerData(server);
	    }

	    @DeleteMapping("/server/{id}")
	    void deleteServer(@PathVariable Long id)  {
	        Service.deleteServerData(id);
	    }



	}

	