package com.axyya.application.service;


import com.axyya.application.Repository.ApplicationRepository;
import com.axyya.application.Entity.Server;
import com.axyya.application.ExceptionHandling.ServerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationService { 
    @Autowired
    ApplicationRepository repository;

    List<Server> list = new ArrayList<>();

   public List<Server> getService()
    {
        List<Server> services = repository.findAll();
        return services;
    }

    public Server getByID(Long id)
    {
         Optional<Server> server = repository.findById(id);

         if(server.isPresent())
         {
             return server.get();
         }
         else {
             throw new ServerException("server not found" + id);
         }

    }
    public Server saveServerData(Server server)
     {
         return repository.save(server);
     }

     // delete data
   public void deleteServerData(Long id)  {
       repository.deleteById(id);
   }

     public  List<Server> getByName(String name)
     {
         List<Server> list1= repository.getByName(name);
         if(list1.isEmpty())
         {
             throw new ServerException("server not found");
         }
         return list1;
     }
     public void updateServer(Server server , Long id)
     {
         list = list.stream().map(o -> {
             if(o.getId()==id)
             {
                 o.setName(server.getName());
                 o.setLanguage(server.getLanguage());
                 o.setFramework(server.getFramework());
             }
             return o;
         }).collect(Collectors.toList());
     }
}
